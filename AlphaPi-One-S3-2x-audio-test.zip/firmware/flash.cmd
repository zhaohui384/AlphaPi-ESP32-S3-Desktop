@echo off
cd /d "%~dp0"
set /p "FLASH_PORT=Serial port (example COM16): "
if not defined FLASH_PORT exit /b 1
python -m esptool --chip esp32s3 --port "%FLASH_PORT%" --baud 115200 --before default_reset --after no_reset write_flash --flash_mode dio --flash_freq 40m --flash_size 8MB 0x0 bootloader.bin 0x8000 partition-table.bin 0xd000 ota_data_initial.bin 0x20000 AlphaPi-One-S3-Desktop.bin
pause
